interface ValidatorConfig {
  [property: string]: {
    [validatableProp: string]: string[]; // ['required', 'positive']
  };
  //Course:{['required', 'positive']}
}

const registeredValidators: ValidatorConfig = {};

//decorator first parameter class constructor and second is property name "title"
function Required(target: any, propName: string) {
  //target.constructor.name gives "Course"
  registeredValidators[target.constructor.name] = {
    ...registeredValidators[target.constructor.name],
    [propName]: ["required"],
  };
  console.log(JSON.stringify(registeredValidators)); //{"Course":{"title":["required"]}}
}

//decorator first parameter class constructor and second is property name "price"
function PositiveNumber(target: any, propName: string) {
  registeredValidators[target.constructor.name] = {
    ...registeredValidators[target.constructor.name],
    [propName]: ["positive"],
  };
  console.log(JSON.stringify(registeredValidators)); //{"Course":{"title":["required"],"price":["positive"]}}
}

function validate(obj: any) {
  const objValidatorConfig = registeredValidators[obj.constructor.name]; //{"title":["required"],"price":["positive"]}
  if (!objValidatorConfig) {
    return true;
  }
  let isValid = true;
  for (const prop in objValidatorConfig) {
    //prop "title" and "price"
    for (const validator of objValidatorConfig[prop]) {
      //objValidatorConfig[prop] are ["required"] and ["positive"]
      //prop are "required" and "positive"
      switch (validator) {
        case "required":
          isValid = isValid && !!obj[prop];
          break;
        case "positive":
          isValid = isValid && obj[prop] > 0;
          break;
      }
    }
  }
  return isValid;
}

class Course {
  @Required
  title: string;
  @PositiveNumber
  price: number;

  constructor(t: string, p: number) {
    this.title = t;
    this.price = p;
  }
}

const courseForm = document.querySelector("form")!;
courseForm.addEventListener("submit", (event) => {
  event.preventDefault(); //prevent form submit
  const titleEl = document.getElementById("title") as HTMLInputElement;
  const priceEl = document.getElementById("price") as HTMLInputElement;

  const title = titleEl.value;
  const price = +priceEl.value; //+ converted to number

  const createdCourse = new Course(title, price);

  //validation is not decorator its an normal function to which we pass an object to validate
  if (!validate(createdCourse)) {
    alert("Invalid input, please try again!");
    return;
  }
  console.log(createdCourse);
});
